# AGENTi V3 Deployment Package

This repository contains the production-ready machine learning models and scripts for AGENTi V3.

## Structure
- `agenti_run.py`: Main execution script.
- `agentI_reg_v3_minmax/`: Regression model directory.
- `agentI_anom_v3_minmax/`: Anomaly detection model directory.
- `autoencoder_v3_minmax.keras`: Keras model file.
- `scaler_v3_minmax.pkl`: Preprocessing scaler.
- `requirements.txt`: Python dependency list.
- `setup.sh`: Shell script to install all dependencies.

## Installation
To set up the environment, run:
```bash
chmod +x setup.sh
./setup.sh
```
