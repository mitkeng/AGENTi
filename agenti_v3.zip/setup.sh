#!/bin/bash
echo "Installing AGENTi V3 Environment..."
# Install from the requirements file in the same directory
pip install -r $(dirname "$0")/requirements.txt
echo "Environment setup complete."
