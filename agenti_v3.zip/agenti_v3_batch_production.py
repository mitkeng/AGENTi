
import argparse
import pandas as pd
import os
from agenti_v3_production import run_inference

def run_batch(input_file, output_file, column_name=None):
    if not os.path.exists(input_file):
        print(f"Error: {input_file} not found.")
        return

    # Handle CSV input
    if input_file.endswith('.csv'):
        df_input = pd.read_csv(input_file)
        if column_name not in df_input.columns:
            print(f"Error: Column '{column_name}' not found in {input_file}")
            print(f"Available columns: {list(df_input.columns)}")
            return
        smiles_list = df_input[column_name].astype(str).tolist()
    else:
        # Default to text file behavior
        with open(input_file, 'r') as f:
            smiles_list = [line.strip() for line in f if line.strip()]

    results = []
    print(f"Processing {len(smiles_list)} SMILES strings...")
    
    for smiles in smiles_list:
        try:
            output = run_inference(smiles)
            results.append({"smiles": smiles, "result": output})
        except Exception as e:
            results.append({"smiles": smiles, "result": f"Error: {str(e)}"})

    df_results = pd.DataFrame(results)
    df_results.to_csv(output_file, index=False)
    print(f"Batch processing complete. Results saved to {output_file}")

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--input', required=True, help='Path to input .txt or .csv file')
    parser.add_argument('--output', default='batch_results.csv', help='Output CSV path')
    parser.add_argument('--column', default='smiles', help='Column name if using CSV (default: smiles)')
    args = parser.parse_args()
    run_batch(args.input, args.output, args.column)
