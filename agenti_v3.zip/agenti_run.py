import tensorflow_decision_forests as tfdf
import argparse
import numpy as np
import pandas as pd
import joblib
import tensorflow as tf
from tensorflow import keras
from rdkit import Chem
from rdkit.Chem import Descriptors, AllChem, rdMolDescriptors, rdMolTransforms
from collections import Counter
import os

# AGENTi V3 Surgical Overdrive v4 Constants
V3_GATE = 1.45
ST_DEV = 0.058
W = 0.35
ALL_FEATURES = [
    'TPSA', 'VSA', 'dihedrals', 'dipole_moment', 'double_bond2', 
    'electronic2', 'halogen', 'hetero2', 'hetero_com_dist', 'logP', 
    'neg_charge', 'pos_charge', 'r_gyr', 'radii_mass2', 'ring2', 
    'solvation_energy', 'triple_bond2', 'tsne_result'
]

def extract_descriptors(smiles):
    mol = Chem.MolFromSmiles(smiles)
    if not mol: return None
    mol_3d = Chem.AddHs(mol)
    try:
        params = AllChem.ETKDGv2()
        params.randomSeed = 42
        AllChem.EmbedMolecule(mol_3d, params)
        AllChem.MMFFOptimizeMolecule(mol_3d, maxIters=500)
        conf = mol_3d.GetConformer()
        coords = conf.GetPositions()
        tpsa = Descriptors.TPSA(mol)
        logp = Descriptors.MolLogP(mol)
        solv_est = -((tpsa * 0.15) / (1.0 + max(0, logp) * 0.1))
        counts = Counter(smiles)
        return {
            'TPSA': round(float(tpsa), 2), 'VSA': round(Descriptors.LabuteASA(mol), 2), 'logP': round(float(logp), 2),
            'radii_mass2': round(Descriptors.MolWt(mol), 2), 'electronic2': round(Descriptors.MaxPartialCharge(mol) or 0.0, 2),
            'double_bond2': float(counts.get("=", 0)), 'triple_bond2': float(counts.get("#", 0)),
            'hetero2': float(Descriptors.NumHeteroatoms(mol)), 'halogen': float(len([a for a in mol.GetAtoms() if a.GetSymbol() in ['F','Cl','Br','I']])),
            'ring2': float(Descriptors.RingCount(mol)), 'pos_charge': float(Descriptors.MaxAbsPartialCharge(mol) or 0.0),
            'neg_charge': float(Descriptors.MinPartialCharge(mol) or 0.0),
            'dihedrals': round(float(np.mean([abs(rdMolTransforms.GetDihedralDeg(conf, *m)) for m in mol_3d.GetSubstructMatches(Chem.MolFromSmarts('[*]~[*]~[*]~[*]'))]) if mol_3d.GetSubstructMatches(Chem.MolFromSmarts('[*]~[*]~[*]~[*]')) else 0.0), 3),
            'dipole_moment': round(float(np.linalg.norm(np.sum(np.array([AllChem.MMFFGetMoleculeProperties(mol_3d).GetMMFFPartialCharge(i) for i in range(mol_3d.GetNumAtoms())])[:, np.newaxis] * coords, axis=0)) * 4.803), 3),
            'hetero_com_dist': round(float(np.linalg.norm(np.mean(coords[[a.GetIdx() for a in mol.GetAtoms() if a.GetSymbol() not in ['C', 'H']]], axis=0))), 3) if any(a.GetSymbol() not in ['C', 'H'] for a in mol.GetAtoms()) else 0.0,
            'r_gyr': round(float(rdMolDescriptors.CalcRadiusOfGyration(mol_3d)), 3),
            'solvation_energy': round(float(solv_est), 3), 'tsne_result': round(float(np.mean(np.linalg.norm(coords - np.mean(coords, axis=0), axis=1))), 3)
        }
    except: return None

def run_inference(smiles):
    scaler = joblib.load('scaler_v3_minmax.pkl')
    auto = keras.models.load_model('autoencoder_v3_minmax.keras')
    anom = tf.saved_model.load('agentI_anom_v3_minmax')
    reg = tf.saved_model.load('agentI_reg_v3_minmax')
    feats = extract_descriptors(smiles)
    if not feats: return "Invalid SMILES"
    df = pd.DataFrame([feats])[ALL_FEATURES]
    X_scaled = scaler.transform(df.values.astype('float32'))
    recon = auto.predict(X_scaled, verbose=0)
    mse = np.mean(np.power(X_scaled - recon, 2))
    tens = {f: tf.convert_to_tensor(df[f].values, dtype=tf.float32) for f in ALL_FEATURES}
    p_anom = next(iter(anom.signatures['serving_default'](**tens).values())).numpy().flatten()[0]
    p_reg = next(iter(reg.signatures['serving_default'](**tens).values())).numpy().flatten()[0]
    mol = Chem.MolFromSmiles(smiles)
    n_count = len([a for a in mol.GetAtoms() if a.GetSymbol() == 'N']) if mol else 0
    rings = Descriptors.RingCount(mol) if mol else 0
    signal = (p_anom + p_reg) / 2
    if n_count >= 2 and rings >= 3: signal *= 3.0
    elif n_count >= 2 and rings >= 2: signal *= 1.8
    score = signal + (np.log1p(mse / ST_DEV) * W)
    return f"A-Score: {score:.3f} | Anomalous: {'Yes' if score >= V3_GATE else 'No'}"

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--smiles', type=str, required=True)
    args = parser.parse_args()
    print(run_inference(args.smiles))